const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// In-memory storage (for demo only)
const orders = [];
const reservations = [];

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// API endpoint to place an order
app.post('/api/order', (req, res) => {
  const order = req.body;

  if (!order || !order.items || order.items.length === 0) {
    return res.status(400).json({ success: false, message: 'Order must contain at least one item.' });
  }

  order.id = orders.length + 1;
  order.createdAt = new Date().toISOString();
  orders.push(order);

  console.log('New order:', order);
  res.json({ success: true, message: 'Order placed successfully!', orderId: order.id });
});

// API endpoint to create a reservation
app.post('/api/reservation', (req, res) => {
  const reservation = req.body;
  const requiredFields = ['name', 'phone', 'date', 'time', 'guests'];

  for (const field of requiredFields) {
    if (!reservation[field]) {
      return res.status(400).json({ success: false, message: `Missing field: ${field}` });
    }
  }

  reservation.id = reservations.length + 1;
  reservation.createdAt = new Date().toISOString();
  reservations.push(reservation);

  console.log('New reservation:', reservation);
  res.json({ success: true, message: 'Table reserved successfully!', reservationId: reservation.id });
});

// Simple endpoint to view all orders and reservations (for testing)
app.get('/api/admin/summary', (req, res) => {
  res.json({ orders, reservations });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});