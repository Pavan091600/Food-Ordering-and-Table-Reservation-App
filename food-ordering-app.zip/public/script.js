// Simple menu data
const MENU = [
  { id: 1, name: 'Margherita Pizza', price: 249, description: 'Classic cheese pizza with fresh basil.' },
  { id: 2, name: 'Veggie Burger', price: 199, description: 'Loaded with fresh veggies and special sauce.' },
  { id: 3, name: 'Pasta Alfredo', price: 279, description: 'Creamy white sauce pasta with herbs.' },
  { id: 4, name: 'Masala Fries', price: 129, description: 'Crispy fries tossed in spicy masala.' },
  { id: 5, name: 'Cold Coffee', price: 99, description: 'Chilled coffee with ice cream.' },
  { id: 6, name: 'Brownie with Ice Cream', price: 149, description: 'Warm brownie served with vanilla ice cream.' }
];

const cart = [];

// Helpers
function formatPrice(value) {
  return value.toFixed(2);
}

// Render menu
function renderMenu() {
  const container = document.getElementById('menu-items');
  container.innerHTML = '';

  MENU.forEach(item => {
    const card = document.createElement('div');
    card.className = 'menu-item';

    card.innerHTML = `
      <div class="menu-item-header">
        <h3>${item.name}</h3>
        <span class="price">₹${item.price}</span>
      </div>
      <p>${item.description}</p>
      <div class="menu-item-actions">
        <input type="number" min="1" value="1" data-id="${item.id}" />
        <button class="primary" data-id="${item.id}">Add</button>
      </div>
    `;

    container.appendChild(card);
  });

  container.addEventListener('click', (e) => {
    if (e.target.tagName === 'BUTTON') {
      const id = Number(e.target.getAttribute('data-id'));
      const item = MENU.find(m => m.id === id);
      const input = container.querySelector(`input[data-id="${id}"]`);
      const qty = Number(input.value) || 1;
      addToCart(item, qty);
    }
  });
}

// Cart functions
function addToCart(item, qty) {
  const existing = cart.find(ci => ci.id === item.id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ ...item, qty });
  }
  renderCart();
}

function removeFromCart(id) {
  const index = cart.findIndex(ci => ci.id === id);
  if (index !== -1) {
    cart.splice(index, 1);
    renderCart();
  }
}

function renderCart() {
  const container = document.getElementById('cart-items');
  const totalSpan = document.getElementById('cart-total');
  const placeOrderBtn = document.getElementById('place-order-btn');

  container.innerHTML = '';

  if (cart.length === 0) {
    container.innerHTML = '<p class="empty">Your cart is empty.</p>';
    totalSpan.textContent = '0.00';
    placeOrderBtn.disabled = true;
    return;
  }

  let total = 0;
  cart.forEach(item => {
    total += item.price * item.qty;
    const row = document.createElement('div');
    row.className = 'cart-item';
    row.innerHTML = `
      <span class="name">${item.name} x ${item.qty}</span>
      <span>₹${formatPrice(item.price * item.qty)}</span>
      <button data-id="${item.id}">Remove</button>
    `;
    container.appendChild(row);
  });

  container.addEventListener('click', (e) => {
    if (e.target.tagName === 'BUTTON') {
      const id = Number(e.target.getAttribute('data-id'));
      removeFromCart(id);
    }
  }, { once: true });

  totalSpan.textContent = formatPrice(total);
  placeOrderBtn.disabled = false;
}

// Place order
async function placeOrder() {
  const name = document.getElementById('customer-name').value.trim();
  const address = document.getElementById('customer-address').value.trim();
  const messageEl = document.getElementById('order-message');

  messageEl.textContent = '';
  messageEl.className = 'message';

  if (!name || !address) {
    messageEl.textContent = 'Please enter your name and address.';
    messageEl.classList.add('error');
    return;
  }

  if (cart.length === 0) {
    messageEl.textContent = 'Your cart is empty.';
    messageEl.classList.add('error');
    return;
  }

  const body = {
    customerName: name,
    customerAddress: address,
    items: cart.map(item => ({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: item.qty
    }))
  };

  try {
    const res = await fetch('/api/order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const data = await res.json();
    if (data.success) {
      messageEl.textContent = `Order placed! Your order ID is ${data.orderId}.`;
      messageEl.classList.add('success');
      cart.length = 0;
      renderCart();
      document.getElementById('customer-name').value = '';
      document.getElementById('customer-address').value = '';
    } else {
      messageEl.textContent = data.message || 'Failed to place order.';
      messageEl.classList.add('error');
    }
  } catch (err) {
    console.error(err);
    messageEl.textContent = 'Server error. Please try again.';
    messageEl.classList.add('error');
  }
}

// Reservation
async function reserveTable() {
  const name = document.getElementById('res-name').value.trim();
  const phone = document.getElementById('res-phone').value.trim();
  const date = document.getElementById('res-date').value;
  const time = document.getElementById('res-time').value;
  const guests = Number(document.getElementById('res-guests').value);
  const notes = document.getElementById('res-notes').value.trim();
  const messageEl = document.getElementById('reservation-message');

  messageEl.textContent = '';
  messageEl.className = 'message';

  if (!name || !phone || !date || !time || !guests) {
    messageEl.textContent = 'Please fill in all required fields.';
    messageEl.classList.add('error');
    return;
  }

  const body = { name, phone, date, time, guests, notes };

  try {
    const res = await fetch('/api/reservation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    const data = await res.json();
    if (data.success) {
      messageEl.textContent = `Reservation confirmed! Your reservation ID is ${data.reservationId}.`;
      messageEl.classList.add('success');
      document.getElementById('res-name').value = '';
      document.getElementById('res-phone').value = '';
      document.getElementById('res-date').value = '';
      document.getElementById('res-time').value = '';
      document.getElementById('res-guests').value = '2';
      document.getElementById('res-notes').value = '';
    } else {
      messageEl.textContent = data.message || 'Failed to reserve table.';
      messageEl.classList.add('error');
    }
  } catch (err) {
    console.error(err);
    messageEl.textContent = 'Server error. Please try again.';
    messageEl.classList.add('error');
  }
}

// Tabs
function setupTabs() {
  const buttons = document.querySelectorAll('.tab-button');
  const tabs = document.querySelectorAll('.tab');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-tab');

      buttons.forEach(b => b.classList.remove('active'));
      tabs.forEach(t => t.classList.remove('active'));

      btn.classList.add('active');
      document.getElementById(target).classList.add('active');
    });
  });
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  renderMenu();
  renderCart();
  setupTabs();

  document.getElementById('place-order-btn').addEventListener('click', placeOrder);
  document.getElementById('reserve-btn').addEventListener('click', reserveTable);
});